#ifndef __MOTORS__
#include "Motors.h"
#endif

#include <Arduino.h>


    /*
    Construtor da classe
    - parametros de entrada:
      - _in1, _in2 - pinos de entrada de sinal, indicando direcao de rotacao
      - _pwmPin - pino que recebera o duty_cycle do pwm dos motores
      - channel - canal em que funcionara o pwm dos motores
    */
Motor::Motor(unsigned char _in1, unsigned char _in2, unsigned char _pwmPin, unsigned char _pwmChannel)
{
  
  // Atribuicao dos pinos
  in1 = _in1;
  in2 = _in2;
  pwmPin = _pwmPin;
  pwmChannel = _pwmChannel;

  // Definicao dos pinos de saida, e do controle de pwm com ledc
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  pinMode(pwmPin, OUTPUT);
  ledcAttachPin(pwmPin, pwmChannel);
  ledcSetup(pwmChannel, PWM_FREQ, PWM_RESOLUTION);

  // Inicialização
  init();
}


  /*
	inicializa os motores
	com valor de pwm zero
	e os motores travados
  */
void Motor::init()
{
  // Escrever 5 para travar o motor
  digitalWrite(in1, HIGH);
  digitalWrite(in2, HIGH);
  ledcWrite(pwmChannel , 0);

  sentidoAtual = -1;
}


    // Funcao ativa o motor em uma velocidade e um sentido
    // - parametros de entrada:
    //   - pwm: velocidade de roda 0 - 255
    //   - sentido: sentido de rotacao: 1-HORARIO 0-ANTIHORARIO
void Motor::enable(unsigned char pwm, bool sentido)
{
  // Para o motor antes de inverter o sentido
  if(sentidoAtual != -1 && sentido != sentidoAtual)
  {
    init();
  }

  digitalWrite(in1, sentido);
  digitalWrite(in2, !sentido);
  ledcWrite(pwmChannel, pwm);
  // Atualiza o sentido
  sentidoAtual = sentido;

  // if(direcao == HORARIO)
  // {
  //   pinMode(in1, OUTPUT);
  //   digitalWrite(in1, 1);
  //   analogWrite(in2, 255 - pwm);
  //   sentido = HORARIO;
  // }
  // else
  // {
  //   pinMode(in2, OUTPUT);
  //   digitalWrite(in2, 1);
  //   analogWrite(in1, 255-pwm);
  //   sentido = ANTIHORARIO;
  // }

  // if(direcao)
  //   sentido = HORARIO;
  // else
  //   sentido = ANTIHORARIO;
  //
  //   digitalWrite(in2, direcao);
  //   analogWrite(in1, pwm);

}
