#ifndef __MOTORS__
#define __MOTORS__

#include <Arduino.h>

// MOTOR CLASS CONSTANTS
#define ANTIHORARIO 0
#define HORARIO 1
#define PWM_FREQ        1000
#define PWM_RESOLUTION  8


class Motor
{
  protected:
    // Pinos de controle do motor
    unsigned char in1; //input de sentido
    unsigned char in2; //input de sentido
    unsigned char pwmPin; //input de pwm dos motores

    unsigned char pwmChannel;

    // Salva o sentido de rotação do motor
    // 0 ANTIHORARIO
    // 1 HORARIO
    // -1 INICIALIZACAO
    char sentidoAtual;
    // Inicializa o motor em ponto morto
    void init();

  public:
    

    Motor(unsigned char, unsigned char, unsigned char, unsigned char);


    void enable(unsigned char, bool);
};

#endif
